
import { Component, OnInit ,Input,Output,EventEmitter} from '@angular/core';

@Component({
  selector: 'app-adivina-el-numero',
  templateUrl: './adivina-el-numero.component.html',
  styleUrls: ['./adivina-el-numero.component.css']
})
export class AdivinaElNumeroComponent implements OnInit {
 @Output() 
 listadoEnviado :EventEmitter<any>= new EventEmitter<any>();

  nombre = 'Adivina el número secreto';
   numeroSecreto=0;
   numeroIngresado=0;
   gano=false;
 
  constructor() { 
          console.info("numero Secreto:",this.numeroSecreto);  
  }


  public generarnumero()
  {
     this.numeroSecreto= Math.floor((Math.random() * 100) + 1);
      console.info("numero Secreto:",this.numeroSecreto);
      this.gano=false;
  }
  public verificar()
  {
   if ( this.numeroIngresado == this.numeroSecreto)
   {
     this.gano=true;
   }
   if(this.gano)
   {
     this.listadoEnviado.emit("hola");
   }

  }
    

  ngOnInit() {
  }

}
