import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms';
import { AppComponent } from '../app.component';
import { NuevoComponent } from '../components/nuevo/nuevo.component';
import { AdivinaElNumeroComponent } from '../adivina-el-numero/adivina-el-numero.component';
import { AgilidadAritmeticaComponent } from '../agilidad-aritmetica/agilidad-aritmetica.component';
import { MenuComponent } from '../menu/menu.component';
import { RouterModule,Routes,RouterOutlet} from '@angular/router';
import { ErrorComponent } from '../error/error.component';
import { LoginComponent } from '../login/login.component';
import { PrincipalComponent } from '../principal/principal.component';
import { ListadoDeResultadosComponent } from '../listado-de-resultados/listado-de-resultados.component';
import { AdivinaMasListadoComponent } from '../adivina-mas-listado/adivina-mas-listado.component';

const MiRuteo = [{path: 'Error' , component: ErrorComponent},
{path:"Login",component:LoginComponent},{path:"Principal",component:PrincipalComponent,pathMatch:"full"}
,{path:"Adivina",component:AdivinaElNumeroComponent},{path:"Agilidad",component:AgilidadAritmeticaComponent}
,{path:"AdivinaListado",component:ListadoDeResultadosComponent},{path:"**",component:ErrorComponent}];


@NgModule({
  declarations: [
    
  ],
  imports: [
    BrowserModule,FormsModule
    ,RouterModule.forRoot(MiRuteo)
  ],
  exports:[
    RouterModule
  ]
  
})
export class RuteandoModule { }
