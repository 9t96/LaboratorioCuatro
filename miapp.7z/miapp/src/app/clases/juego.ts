export class Juego {
    nombre:string;
    jugador:string;
    gano:boolean;
    numeroSecreto:number;
    numeroIngresado:number;

    constructor(nombre:string,jugador:string,gano:boolean,numeroSecreto=0,numeroIngresado=0)
    {
        this.nombre=nombre;
        this.jugador=jugador;
        this.gano=gano;
        this.numeroSecreto=numeroSecreto;
        this.numeroIngresado=numeroIngresado;
    }

    public generarNumero(){
        this.numeroSecreto = Math.floor((Math.random()*100)+1);
        console.info("numero secreto: "+this.numeroSecreto);
        this.gano=false;
    }

    public verificar()
    {
        if(this.numeroIngresado===this.numeroSecreto)
        this.gano=true;
        if(this.gano){
        return true;
         } else
        return false;
    }
}

