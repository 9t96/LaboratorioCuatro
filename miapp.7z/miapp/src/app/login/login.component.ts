import { Component, OnInit } from '@angular/core';
import { ActivatedRoute,Router,ParamMap} from '@angular/router';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})

export class LoginComponent implements OnInit {
 usuario:string;
 password:string;

  constructor(
  private route:ActivatedRoute,private router:Router){
   }
verificarNumero(event){
if(this.usuario=="admin" && this.password=="admin")
{
 this.router.navigate(["/Principal"]);
}else{
  this.router.navigate(["/Login"]);
}
}

  
  ngOnInit() {
  }

}
